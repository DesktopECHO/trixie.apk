var searchData=
[
  ['0_20is_20a_20legal_20port_20per_20rfc_201700_20this_20should_0',['FIXME: 0 is a legal port (per RFC 1700). this should',['../group__apr__network__io.html#autotoc_md0',1,'']]]
];
