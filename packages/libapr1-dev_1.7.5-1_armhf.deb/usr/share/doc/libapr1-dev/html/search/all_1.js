var searchData=
[
  ['1700_20this_20should_0',['FIXME: 0 is a legal port (per RFC 1700). this should',['../group__apr__network__io.html#autotoc_md0',1,'']]]
];
