var searchData=
[
  ['o_20handling_20functions_0',['File I/O Handling Functions',['../group__apr__file__io.html',1,'']]],
  ['object_20handling_1',['Dynamic Object Handling',['../group__apr__dso.html',1,'']]],
  ['object_20permission_20set_20functions_2',['Object permission set functions',['../group__apr__perms__set.html',1,'']]],
  ['open_20flags_20routines_3',['File Open Flags/Routines',['../group__apr__file__open__flags.html',1,'']]],
  ['operations_4',['Atomic Operations',['../group__apr__atomic.html',1,'']]],
  ['opt_5',['opt',['../structapr__getopt__t.html#a4f842391b8f8f19e562584fdd29d0654',1,'apr_getopt_t']]],
  ['optch_6',['optch',['../structapr__getopt__option__t.html#a476e67c4dde620fe5b4f5952238c6e94',1,'apr_getopt_option_t']]],
  ['option_20definitions_7',['Socket option definitions',['../group__apr__sockopt.html',1,'']]],
  ['options_8',['Poll options',['../group__pollopts.html',1,'']]],
  ['os_5fsock_9',['os_sock',['../structapr__os__sock__info__t.html#a952464d2f91ca4650e8b4848a81745b5',1,'apr_os_sock_info_t']]],
  ['other_20child_20flags_10',['Other Child Flags',['../group___a_p_r___o_c.html',1,'']]],
  ['out_11',['out',['../structapr__proc__t.html#acb7d7c5226217946d761f0e90ff70d24',1,'apr_proc_t']]]
];
