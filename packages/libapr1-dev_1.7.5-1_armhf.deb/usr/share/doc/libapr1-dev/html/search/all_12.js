var searchData=
[
  ['random_20functions_0',['Random Functions',['../group__apr__random.html',1,'']]],
  ['reader_20writer_20lock_20routines_1',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]],
  ['ref_2',['ref',['../structapr__memnode__t.html#ac68a939c0c3d48498ec0c0fde409c502',1,'apr_memnode_t']]],
  ['remote_3',['remote',['../structapr__os__sock__info__t.html#ae71fe14a5eb9141fc4ad0a6d0a91f17e',1,'apr_os_sock_info_t']]],
  ['reqevents_4',['reqevents',['../structapr__pollfd__t.html#abcedac7097a97823a38ece6e47f4ea9f',1,'apr_pollfd_t']]],
  ['reset_5',['reset',['../structapr__getopt__t.html#abc4e72bc761666c0b0d9015c3b0de8c3',1,'apr_getopt_t']]],
  ['return_20something_20besides_20zero_20if_20the_20port_20is_20missing_6',['return something besides zero if the port is missing.',['../group__apr__network__io.html#autotoc_md1',1,'']]],
  ['rfc_201700_20this_20should_7',['FIXME: 0 is a legal port (per RFC 1700). this should',['../group__apr__network__io.html#autotoc_md0',1,'']]],
  ['ring_20macro_20implementations_8',['Ring Macro Implementations',['../group__apr__ring.html',1,'']]],
  ['routines_9',['routines',['../group__apr__thread__cond.html',1,'Condition Variable Routines'],['../group__apr__os__dso.html',1,'DSO (Dynamic Loading) Portability Routines'],['../group__apr__file__open__flags.html',1,'File Open Flags/Routines'],['../group__apr__lib.html',1,'General Purpose Library Routines'],['../group___a_p_r___global_mutex.html',1,'Global Locking Routines'],['../group__apr__general.html',1,'Miscellaneous library routines'],['../group__apr__mmap.html',1,'MMAP (Memory Map) Routines'],['../group__apr__network__io.html',1,'Network Routines'],['../group__apr__poll.html',1,'Poll Routines'],['../group__apr__portabile.html',1,'Portability Routines'],['../group__apr__proc__mutex.html',1,'Process Locking Routines'],['../group__apr__thread__rwlock.html',1,'Reader/Writer Lock Routines'],['../group__apr__shm.html',1,'Shared Memory Routines'],['../group__apr__strings.html',1,'String routines'],['../group__apr__thread__mutex.html',1,'Thread Mutex Routines'],['../group__apr__os__thread.html',1,'Thread portability Routines'],['../group__apr__time.html',1,'Time Routines']]],
  ['rtnevents_10',['rtnevents',['../structapr__pollfd__t.html#aed5b2109b27984975309922bfa84e3f6',1,'apr_pollfd_t']]],
  ['runtime_20library_11',['Apache Portability Runtime library',['../group___a_p_r.html',1,'']]]
];
