var searchData=
[
  ['use_20when_20creating_20sockets_0',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['user_1',['user',['../structapr__finfo__t.html#ab79d14bd50f50662d29ad433166c4bc5',1,'apr_finfo_t']]],
  ['user_20and_20group_20id_20services_2',['User and Group ID Services',['../group__apr__user.html',1,'']]]
];
