var searchData=
[
  ['val_0',['val',['../structapr__table__entry__t.html#a755371d0aa6a9487b502c34807271e6f',1,'apr_table_entry_t']]],
  ['valid_1',['valid',['../structapr__finfo__t.html#aff0cdf06637edec63c4701e582792019',1,'apr_finfo_t']]],
  ['value_20tests_2',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['values_3',['APR Error Values',['../group___a_p_r___error.html',1,'']]],
  ['variable_20routines_4',['Condition Variable Routines',['../group__apr__thread__cond.html',1,'']]]
];
