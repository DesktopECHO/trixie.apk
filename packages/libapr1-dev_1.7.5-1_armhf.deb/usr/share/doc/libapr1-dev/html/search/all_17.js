var searchData=
[
  ['when_20creating_20sockets_0',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['writer_20lock_20routines_1',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]]
];
