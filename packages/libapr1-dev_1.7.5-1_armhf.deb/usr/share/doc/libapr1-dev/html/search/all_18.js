var searchData=
[
  ['zero_20if_20the_20port_20is_20missing_0',['return something besides zero if the port is missing.',['../group__apr__network__io.html#autotoc_md1',1,'']]]
];
