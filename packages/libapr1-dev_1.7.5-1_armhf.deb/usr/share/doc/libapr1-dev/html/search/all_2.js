var searchData=
[
  ['_5ffull_20max_20iovec_20size_0',['{_full} max iovec size',['../group__apr__file__writev.html',1,'']]]
];
