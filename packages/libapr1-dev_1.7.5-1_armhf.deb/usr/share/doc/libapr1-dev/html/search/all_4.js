var searchData=
[
  ['base16_20encoding_0',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['base32_20base32hex_20base16_20encoding_1',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['base32hex_20base16_20encoding_2',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['base64_20base64url_20base32_20base32hex_20base16_20encoding_3',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['base64url_20base32_20base32hex_20base16_20encoding_4',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['besides_20zero_20if_20the_20port_20is_20missing_5',['return something besides zero if the port is missing.',['../group__apr__network__io.html#autotoc_md1',1,'']]],
  ['bug_20list_6',['Bug List',['../bug.html',1,'']]]
];
