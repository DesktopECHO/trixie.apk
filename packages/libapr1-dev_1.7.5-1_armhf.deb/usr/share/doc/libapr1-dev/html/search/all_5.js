var searchData=
[
  ['c_20posix_20locale_20string_20functions_0',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['child_20flags_1',['Other Child Flags',['../group___a_p_r___o_c.html',1,'']]],
  ['cleanup_20functions_2',['Pool Cleanup Functions',['../group___pool_cleanup.html',1,'']]],
  ['client_5fdata_3',['client_data',['../structapr__pollfd__t.html#a01220e7a71963456461baa40b2a05716',1,'apr_pollfd_t']]],
  ['cntxt_4',['cntxt',['../structapr__mmap__t.html#a42d01080278bbc9bad26728f9a71c492',1,'apr_mmap_t']]],
  ['codes_5',['Error Codes',['../group__apr__errno.html',1,'']]],
  ['command_20argument_20parsing_6',['Command Argument Parsing',['../group__apr__getopt.html',1,'']]],
  ['condition_20variable_20routines_7',['Condition Variable Routines',['../group__apr__thread__cond.html',1,'']]],
  ['cont_8',['cont',['../structapr__getopt__t.html#a63a073fb9c11bb2713b3d7f967e95a24',1,'apr_getopt_t']]],
  ['creating_20sockets_9',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['csize_10',['csize',['../structapr__finfo__t.html#aeaa4a4def98ad4f162e05c2e2292321d',1,'apr_finfo_t']]],
  ['ctime_11',['ctime',['../structapr__finfo__t.html#aebbdb3dc755d825de3dce901cfba0883',1,'apr_finfo_t']]],
  ['ctype_20functions_12',['ctype functions',['../group__apr__ctype.html',1,'']]],
  ['curpos_13',['curpos',['../structapr__vformatter__buff__t.html#aad69bb2ce382b39f55df6cc59039aee9',1,'apr_vformatter_buff_t']]]
];
