var searchData=
[
  ['debugging_20functions_0',['Pool Debugging functions',['../group___pool_debug.html',1,'']]],
  ['definitions_1',['definitions',['../group__apr__platform.html',1,'Platform Definitions'],['../group__apr__sockopt.html',1,'Socket option definitions']]],
  ['definitions_20for_20use_20when_20creating_20sockets_2',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['deprecated_20list_3',['Deprecated List',['../deprecated.html',1,'']]],
  ['desc_4',['desc',['../structapr__pollfd__t.html#ad63baa71bb91f80513d33482e28fb967',1,'apr_pollfd_t']]],
  ['desc_5ftype_5',['desc_type',['../structapr__pollfd__t.html#acfafd260241a874745f49ba2df246c53',1,'apr_pollfd_t']]],
  ['description_6',['description',['../structapr__getopt__option__t.html#a8fd515c0a9e621f6c0d058772429ab98',1,'apr_getopt_option_t']]],
  ['device_7',['device',['../structapr__finfo__t.html#a38cbfbff641284065481f5907d59c8bf',1,'apr_finfo_t']]],
  ['directory_20manipulation_20functions_8',['Directory Manipulation Functions',['../group__apr__dir.html',1,'']]],
  ['dso_20dynamic_20loading_20portability_20routines_9',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['dynamic_20loading_20portability_20routines_10',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['dynamic_20object_20handling_11',['Dynamic Object Handling',['../group__apr__dso.html',1,'']]]
];
