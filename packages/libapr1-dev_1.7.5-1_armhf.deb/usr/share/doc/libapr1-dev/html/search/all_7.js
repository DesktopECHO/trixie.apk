var searchData=
[
  ['elt_5fsize_0',['elt_size',['../structapr__array__header__t.html#a36a690ebc781edc9e99ac1bec53c1770',1,'apr_array_header_t']]],
  ['elts_1',['elts',['../structapr__array__header__t.html#af8462fa2a1ddf6406c66cd3dd441a269',1,'apr_array_header_t']]],
  ['encoding_2',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['endp_3',['endp',['../structapr__memnode__t.html#a35c9bf71f1cc680929f857176b547a05',1,'apr_memnode_t']]],
  ['endpos_4',['endpos',['../structapr__vformatter__buff__t.html#ab4884e759f4285c72df93e0d63022675',1,'apr_vformatter_buff_t']]],
  ['environment_5',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['err_6',['err',['../structapr__proc__t.html#ad087f812b5c69ce937db4cf6e8cd5a0b',1,'apr_proc_t']]],
  ['errarg_7',['errarg',['../structapr__getopt__t.html#a46db55c58789ab7fa99bb49544b0776e',1,'apr_getopt_t']]],
  ['errfn_8',['errfn',['../structapr__getopt__t.html#a6bf3fd7ad92d1f0161cd895e1ad50d06',1,'apr_getopt_t']]],
  ['error_20codes_9',['Error Codes',['../group__apr__errno.html',1,'']]],
  ['error_20space_10',['APR Error Space',['../group___a_p_r___e_r_r_o_r__map.html',1,'']]],
  ['error_20values_11',['APR Error Values',['../group___a_p_r___error.html',1,'']]],
  ['escape_20functions_12',['Escape functions',['../group___a_p_r___util___escaping.html',1,'']]]
];
