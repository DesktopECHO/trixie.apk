var searchData=
[
  ['general_20purpose_20library_20routines_0',['General Purpose Library Routines',['../group__apr__lib.html',1,'']]],
  ['global_20locking_20routines_1',['Global Locking Routines',['../group___a_p_r___global_mutex.html',1,'']]],
  ['group_2',['group',['../structapr__finfo__t.html#a15c9c056330308de4dafb3826a9b02bc',1,'apr_finfo_t']]],
  ['group_20id_20services_3',['User and Group ID Services',['../group__apr__user.html',1,'']]]
];
