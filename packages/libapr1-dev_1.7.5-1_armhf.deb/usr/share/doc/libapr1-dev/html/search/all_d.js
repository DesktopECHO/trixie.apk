var searchData=
[
  ['legal_20port_20per_20rfc_201700_20this_20should_0',['FIXME: 0 is a legal port (per RFC 1700). this should',['../group__apr__network__io.html#autotoc_md0',1,'']]],
  ['library_1',['Apache Portability Runtime library',['../group___a_p_r.html',1,'']]],
  ['library_20initialization_20and_20termination_2',['Library initialization and termination',['../group__apr__library.html',1,'']]],
  ['library_20routines_3',['library routines',['../group__apr__lib.html',1,'General Purpose Library Routines'],['../group__apr__general.html',1,'Miscellaneous library routines']]],
  ['list_4',['list',['../bug.html',1,'Bug List'],['../deprecated.html',1,'Deprecated List']]],
  ['list_20implementation_5',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['loading_20portability_20routines_6',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['local_7',['local',['../structapr__os__sock__info__t.html#afaf470560cbc3088479af708878aa086',1,'apr_os_sock_info_t']]],
  ['locale_20string_20functions_8',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['lock_20routines_9',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]],
  ['lock_20types_10',['File Lock Types',['../group__apr__file__lock__types.html',1,'']]],
  ['locking_20routines_11',['locking routines',['../group___a_p_r___global_mutex.html',1,'Global Locking Routines'],['../group__apr__proc__mutex.html',1,'Process Locking Routines']]]
];
