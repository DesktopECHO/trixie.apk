var searchData=
[
  ['macro_20implementations_0',['Ring Macro Implementations',['../group__apr__ring.html',1,'']]],
  ['major_1',['major',['../structapr__version__t.html#a0ae64fee85387834ab76d9f9288373ab',1,'apr_version_t']]],
  ['manipulating_20the_20environment_2',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['manipulation_20functions_3',['manipulation functions',['../group__apr__dir.html',1,'Directory Manipulation Functions'],['../group__apr__filepath.html',1,'Filepath Manipulation Functions']]],
  ['map_20routines_4',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['matching_20functions_5',['Filename Matching Functions',['../group__apr__fnmatch.html',1,'']]],
  ['max_20iovec_20size_6',['{_full} max iovec size',['../group__apr__file__writev.html',1,'']]],
  ['memmove_7',['memmove',['../group__apr__general.html#gad12df83f1d3a090b658adc645555ca79',1,'apr_general.h']]],
  ['memory_20allocation_8',['Internal Memory Allocation',['../group__apr__allocator.html',1,'']]],
  ['memory_20map_20routines_9',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['memory_20pool_20functions_10',['Memory Pool Functions',['../group__apr__pools.html',1,'']]],
  ['memory_20routines_11',['Shared Memory Routines',['../group__apr__shm.html',1,'']]],
  ['minor_12',['minor',['../structapr__version__t.html#aab0a1e8362517416389631bceeeedbad',1,'apr_version_t']]],
  ['miscellaneous_20library_20routines_13',['Miscellaneous library routines',['../group__apr__general.html',1,'']]],
  ['missing_14',['return something besides zero if the port is missing.',['../group__apr__network__io.html#autotoc_md1',1,'']]],
  ['mm_15',['mm',['../structapr__mmap__t.html#abcc62d7e7c8187311e6619faf0d44f19',1,'apr_mmap_t']]],
  ['mmap_20memory_20map_20routines_16',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['mtime_17',['mtime',['../structapr__finfo__t.html#afc3bec0f6b3b10160428ba5602a41c60',1,'apr_finfo_t']]],
  ['multicast_18',['IP Multicast',['../group__apr__mcast.html',1,'']]],
  ['mutex_20routines_19',['Thread Mutex Routines',['../group__apr__thread__mutex.html',1,'']]]
];
