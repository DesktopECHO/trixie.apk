var searchData=
[
  ['seek_20flags_0',['File Seek Flags',['../group__apr__file__seek__flags.html',1,'']]],
  ['services_1',['User and Group ID Services',['../group__apr__user.html',1,'']]],
  ['set_20functions_2',['Object permission set functions',['../group__apr__perms__set.html',1,'']]],
  ['shared_20memory_20routines_3',['Shared Memory Routines',['../group__apr__shm.html',1,'']]],
  ['signal_20handling_4',['Signal Handling',['../group__apr__signal.html',1,'']]],
  ['size_5',['{_full} max iovec size',['../group__apr__file__writev.html',1,'']]],
  ['skip_20list_20implementation_6',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['snprintf_20implementations_7',['snprintf implementations',['../group___a_p_r___strings___snprintf.html',1,'']]],
  ['socket_20option_20definitions_8',['Socket option definitions',['../group__apr__sockopt.html',1,'']]],
  ['sockets_9',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['space_10',['APR Error Space',['../group___a_p_r___e_r_r_o_r__map.html',1,'']]],
  ['stat_20functions_11',['Stat Functions',['../group__apr__file__stat.html',1,'']]],
  ['status_20value_20tests_12',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['string_20functions_13',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['string_20routines_14',['String routines',['../group__apr__strings.html',1,'']]],
  ['support_20functions_15',['Internal APR support functions',['../group__apr__support.html',1,'']]]
];
