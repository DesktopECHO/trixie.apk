var searchData=
[
  ['table_20and_20array_20functions_0',['Table and Array Functions',['../group__apr__tables.html',1,'']]],
  ['tables_1',['Hash Tables',['../group__apr__hash.html',1,'']]],
  ['termination_2',['Library initialization and termination',['../group__apr__library.html',1,'']]],
  ['tests_3',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['the_20environment_4',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['thread_20mutex_20routines_5',['Thread Mutex Routines',['../group__apr__thread__mutex.html',1,'']]],
  ['thread_20portability_20routines_6',['Thread portability Routines',['../group__apr__os__thread.html',1,'']]],
  ['threads_20and_20process_20functions_7',['Threads and Process Functions',['../group__apr__thread__proc.html',1,'']]],
  ['time_20routines_8',['Time Routines',['../group__apr__time.html',1,'']]],
  ['types_9',['File Lock Types',['../group__apr__file__lock__types.html',1,'']]]
];
