var searchData=
[
  ['use_20when_20creating_20sockets_0',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['user_20and_20group_20id_20services_1',['User and Group ID Services',['../group__apr__user.html',1,'']]]
];
