var searchData=
[
  ['value_20tests_0',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['values_1',['APR Error Values',['../group___a_p_r___error.html',1,'']]],
  ['variable_20routines_2',['Condition Variable Routines',['../group__apr__thread__cond.html',1,'']]]
];
