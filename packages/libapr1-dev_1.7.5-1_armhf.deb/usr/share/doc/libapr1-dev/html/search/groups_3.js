var searchData=
[
  ['c_20posix_20locale_20string_20functions_0',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['child_20flags_1',['Other Child Flags',['../group___a_p_r___o_c.html',1,'']]],
  ['cleanup_20functions_2',['Pool Cleanup Functions',['../group___pool_cleanup.html',1,'']]],
  ['codes_3',['Error Codes',['../group__apr__errno.html',1,'']]],
  ['command_20argument_20parsing_4',['Command Argument Parsing',['../group__apr__getopt.html',1,'']]],
  ['condition_20variable_20routines_5',['Condition Variable Routines',['../group__apr__thread__cond.html',1,'']]],
  ['creating_20sockets_6',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['ctype_20functions_7',['ctype functions',['../group__apr__ctype.html',1,'']]]
];
