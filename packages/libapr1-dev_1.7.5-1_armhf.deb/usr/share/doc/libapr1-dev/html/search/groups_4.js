var searchData=
[
  ['debugging_20functions_0',['Pool Debugging functions',['../group___pool_debug.html',1,'']]],
  ['definitions_1',['definitions',['../group__apr__platform.html',1,'Platform Definitions'],['../group__apr__sockopt.html',1,'Socket option definitions']]],
  ['definitions_20for_20use_20when_20creating_20sockets_2',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['directory_20manipulation_20functions_3',['Directory Manipulation Functions',['../group__apr__dir.html',1,'']]],
  ['dso_20dynamic_20loading_20portability_20routines_4',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['dynamic_20loading_20portability_20routines_5',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['dynamic_20object_20handling_6',['Dynamic Object Handling',['../group__apr__dso.html',1,'']]]
];
