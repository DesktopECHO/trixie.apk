var searchData=
[
  ['encoding_0',['Base64/Base64Url/Base32/Base32Hex/Base16 Encoding',['../group___a_p_r___util___encode.html',1,'']]],
  ['environment_1',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['error_20codes_2',['Error Codes',['../group__apr__errno.html',1,'']]],
  ['error_20space_3',['APR Error Space',['../group___a_p_r___e_r_r_o_r__map.html',1,'']]],
  ['error_20values_4',['APR Error Values',['../group___a_p_r___error.html',1,'']]],
  ['escape_20functions_5',['Escape functions',['../group___a_p_r___util___escaping.html',1,'']]]
];
