var searchData=
[
  ['file_20attribute_20flags_0',['File Attribute Flags',['../group__apr__file__attrs__set__flags.html',1,'']]],
  ['file_20i_20o_20handling_20functions_1',['File I/O Handling Functions',['../group__apr__file__io.html',1,'']]],
  ['file_20information_2',['File Information',['../group__apr__file__info.html',1,'']]],
  ['file_20lock_20types_3',['File Lock Types',['../group__apr__file__lock__types.html',1,'']]],
  ['file_20open_20flags_20routines_4',['File Open Flags/Routines',['../group__apr__file__open__flags.html',1,'']]],
  ['file_20permissions_20flags_5',['File Permissions flags',['../group__apr__file__permissions.html',1,'']]],
  ['file_20seek_20flags_6',['File Seek Flags',['../group__apr__file__seek__flags.html',1,'']]],
  ['filename_20matching_20functions_7',['Filename Matching Functions',['../group__apr__fnmatch.html',1,'']]],
  ['filepath_20manipulation_20functions_8',['Filepath Manipulation Functions',['../group__apr__filepath.html',1,'']]],
  ['flags_9',['flags',['../group__apr__file__attrs__set__flags.html',1,'File Attribute Flags'],['../group__apr__file__permissions.html',1,'File Permissions flags'],['../group__apr__file__seek__flags.html',1,'File Seek Flags'],['../group___a_p_r___o_c.html',1,'Other Child Flags'],['../group__pollflags.html',1,'Pollset Flags']]],
  ['flags_20routines_10',['File Open Flags/Routines',['../group__apr__file__open__flags.html',1,'']]],
  ['for_20manipulating_20the_20environment_11',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['for_20use_20when_20creating_20sockets_12',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['functions_13',['functions',['../group__apr__cstr.html',1,'C (POSIX) locale string functions'],['../group__apr__ctype.html',1,'ctype functions'],['../group__apr__dir.html',1,'Directory Manipulation Functions'],['../group___a_p_r___util___escaping.html',1,'Escape functions'],['../group__apr__file__io.html',1,'File I/O Handling Functions'],['../group__apr__fnmatch.html',1,'Filename Matching Functions'],['../group__apr__filepath.html',1,'Filepath Manipulation Functions'],['../group__apr__support.html',1,'Internal APR support functions'],['../group__apr__pools.html',1,'Memory Pool Functions'],['../group__apr__perms__set.html',1,'Object permission set functions'],['../group___pool_cleanup.html',1,'Pool Cleanup Functions'],['../group___pool_debug.html',1,'Pool Debugging functions'],['../group__apr__random.html',1,'Random Functions'],['../group__apr__file__stat.html',1,'Stat Functions'],['../group__apr__tables.html',1,'Table and Array Functions'],['../group__apr__thread__proc.html',1,'Threads and Process Functions']]],
  ['functions_20for_20manipulating_20the_20environment_14',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]]
];
