var searchData=
[
  ['general_20purpose_20library_20routines_0',['General Purpose Library Routines',['../group__apr__lib.html',1,'']]],
  ['global_20locking_20routines_1',['Global Locking Routines',['../group___a_p_r___global_mutex.html',1,'']]],
  ['group_20id_20services_2',['User and Group ID Services',['../group__apr__user.html',1,'']]]
];
