var searchData=
[
  ['i_20o_20handling_20functions_0',['File I/O Handling Functions',['../group__apr__file__io.html',1,'']]],
  ['id_20services_1',['User and Group ID Services',['../group__apr__user.html',1,'']]],
  ['implementation_2',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['implementations_3',['implementations',['../group__apr__ring.html',1,'Ring Macro Implementations'],['../group___a_p_r___strings___snprintf.html',1,'snprintf implementations']]],
  ['information_4',['File Information',['../group__apr__file__info.html',1,'']]],
  ['initialization_20and_20termination_5',['Library initialization and termination',['../group__apr__library.html',1,'']]],
  ['internal_20apr_20support_20functions_6',['Internal APR support functions',['../group__apr__support.html',1,'']]],
  ['internal_20memory_20allocation_7',['Internal Memory Allocation',['../group__apr__allocator.html',1,'']]],
  ['iovec_20size_8',['{_full} max iovec size',['../group__apr__file__writev.html',1,'']]],
  ['ip_20multicast_9',['IP Multicast',['../group__apr__mcast.html',1,'']]],
  ['ip_20protocol_20definitions_20for_20use_20when_20creating_20sockets_10',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]]
];
