var searchData=
[
  ['library_0',['Apache Portability Runtime library',['../group___a_p_r.html',1,'']]],
  ['library_20initialization_20and_20termination_1',['Library initialization and termination',['../group__apr__library.html',1,'']]],
  ['library_20routines_2',['library routines',['../group__apr__lib.html',1,'General Purpose Library Routines'],['../group__apr__general.html',1,'Miscellaneous library routines']]],
  ['list_20implementation_3',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['loading_20portability_20routines_4',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['locale_20string_20functions_5',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['lock_20routines_6',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]],
  ['lock_20types_7',['File Lock Types',['../group__apr__file__lock__types.html',1,'']]],
  ['locking_20routines_8',['locking routines',['../group___a_p_r___global_mutex.html',1,'Global Locking Routines'],['../group__apr__proc__mutex.html',1,'Process Locking Routines']]]
];
