var searchData=
[
  ['macro_20implementations_0',['Ring Macro Implementations',['../group__apr__ring.html',1,'']]],
  ['manipulating_20the_20environment_1',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['manipulation_20functions_2',['manipulation functions',['../group__apr__dir.html',1,'Directory Manipulation Functions'],['../group__apr__filepath.html',1,'Filepath Manipulation Functions']]],
  ['map_20routines_3',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['matching_20functions_4',['Filename Matching Functions',['../group__apr__fnmatch.html',1,'']]],
  ['max_20iovec_20size_5',['{_full} max iovec size',['../group__apr__file__writev.html',1,'']]],
  ['memory_20allocation_6',['Internal Memory Allocation',['../group__apr__allocator.html',1,'']]],
  ['memory_20map_20routines_7',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['memory_20pool_20functions_8',['Memory Pool Functions',['../group__apr__pools.html',1,'']]],
  ['memory_20routines_9',['Shared Memory Routines',['../group__apr__shm.html',1,'']]],
  ['miscellaneous_20library_20routines_10',['Miscellaneous library routines',['../group__apr__general.html',1,'']]],
  ['mmap_20memory_20map_20routines_11',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['multicast_12',['IP Multicast',['../group__apr__mcast.html',1,'']]],
  ['mutex_20routines_13',['Thread Mutex Routines',['../group__apr__thread__mutex.html',1,'']]]
];
