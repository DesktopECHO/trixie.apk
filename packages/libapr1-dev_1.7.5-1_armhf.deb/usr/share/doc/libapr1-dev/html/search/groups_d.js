var searchData=
[
  ['o_20handling_20functions_0',['File I/O Handling Functions',['../group__apr__file__io.html',1,'']]],
  ['object_20handling_1',['Dynamic Object Handling',['../group__apr__dso.html',1,'']]],
  ['object_20permission_20set_20functions_2',['Object permission set functions',['../group__apr__perms__set.html',1,'']]],
  ['open_20flags_20routines_3',['File Open Flags/Routines',['../group__apr__file__open__flags.html',1,'']]],
  ['operations_4',['Atomic Operations',['../group__apr__atomic.html',1,'']]],
  ['option_20definitions_5',['Socket option definitions',['../group__apr__sockopt.html',1,'']]],
  ['options_6',['Poll options',['../group__pollopts.html',1,'']]],
  ['other_20child_20flags_7',['Other Child Flags',['../group___a_p_r___o_c.html',1,'']]]
];
