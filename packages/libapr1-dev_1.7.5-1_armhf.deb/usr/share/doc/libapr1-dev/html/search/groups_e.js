var searchData=
[
  ['parsing_0',['Command Argument Parsing',['../group__apr__getopt.html',1,'']]],
  ['permission_20set_20functions_1',['Object permission set functions',['../group__apr__perms__set.html',1,'']]],
  ['permissions_20flags_2',['File Permissions flags',['../group__apr__file__permissions.html',1,'']]],
  ['platform_20definitions_3',['Platform Definitions',['../group__apr__platform.html',1,'']]],
  ['poll_20options_4',['Poll options',['../group__pollopts.html',1,'']]],
  ['poll_20routines_5',['Poll Routines',['../group__apr__poll.html',1,'']]],
  ['pollset_20flags_6',['Pollset Flags',['../group__pollflags.html',1,'']]],
  ['pool_20cleanup_20functions_7',['Pool Cleanup Functions',['../group___pool_cleanup.html',1,'']]],
  ['pool_20debugging_20functions_8',['Pool Debugging functions',['../group___pool_debug.html',1,'']]],
  ['pool_20functions_9',['Memory Pool Functions',['../group__apr__pools.html',1,'']]],
  ['portability_20routines_10',['portability routines',['../group__apr__os__dso.html',1,'DSO (Dynamic Loading) Portability Routines'],['../group__apr__portabile.html',1,'Portability Routines'],['../group__apr__os__thread.html',1,'Thread portability Routines']]],
  ['portability_20runtime_20library_11',['Apache Portability Runtime library',['../group___a_p_r.html',1,'']]],
  ['posix_20locale_20string_20functions_12',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['process_20functions_13',['Threads and Process Functions',['../group__apr__thread__proc.html',1,'']]],
  ['process_20locking_20routines_14',['Process Locking Routines',['../group__apr__proc__mutex.html',1,'']]],
  ['protocol_20definitions_20for_20use_20when_20creating_20sockets_15',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['purpose_20library_20routines_16',['General Purpose Library Routines',['../group__apr__lib.html',1,'']]]
];
