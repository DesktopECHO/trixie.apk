var searchData=
[
  ['random_20functions_0',['Random Functions',['../group__apr__random.html',1,'']]],
  ['reader_20writer_20lock_20routines_1',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]],
  ['ring_20macro_20implementations_2',['Ring Macro Implementations',['../group__apr__ring.html',1,'']]],
  ['routines_3',['routines',['../group__apr__thread__cond.html',1,'Condition Variable Routines'],['../group__apr__os__dso.html',1,'DSO (Dynamic Loading) Portability Routines'],['../group__apr__file__open__flags.html',1,'File Open Flags/Routines'],['../group__apr__lib.html',1,'General Purpose Library Routines'],['../group___a_p_r___global_mutex.html',1,'Global Locking Routines'],['../group__apr__general.html',1,'Miscellaneous library routines'],['../group__apr__mmap.html',1,'MMAP (Memory Map) Routines'],['../group__apr__network__io.html',1,'Network Routines'],['../group__apr__poll.html',1,'Poll Routines'],['../group__apr__portabile.html',1,'Portability Routines'],['../group__apr__proc__mutex.html',1,'Process Locking Routines'],['../group__apr__thread__rwlock.html',1,'Reader/Writer Lock Routines'],['../group__apr__shm.html',1,'Shared Memory Routines'],['../group__apr__strings.html',1,'String routines'],['../group__apr__thread__mutex.html',1,'Thread Mutex Routines'],['../group__apr__os__thread.html',1,'Thread portability Routines'],['../group__apr__time.html',1,'Time Routines']]],
  ['runtime_20library_4',['Apache Portability Runtime library',['../group___a_p_r.html',1,'']]]
];
