var searchData=
[
  ['val_0',['val',['../structapr__table__entry__t.html#a755371d0aa6a9487b502c34807271e6f',1,'apr_table_entry_t']]],
  ['valid_1',['valid',['../structapr__finfo__t.html#aff0cdf06637edec63c4701e582792019',1,'apr_finfo_t']]]
];
