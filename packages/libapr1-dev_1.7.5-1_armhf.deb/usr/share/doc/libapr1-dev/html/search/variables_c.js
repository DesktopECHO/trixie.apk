var searchData=
[
  ['opt_0',['opt',['../structapr__getopt__t.html#a4f842391b8f8f19e562584fdd29d0654',1,'apr_getopt_t']]],
  ['optch_1',['optch',['../structapr__getopt__option__t.html#a476e67c4dde620fe5b4f5952238c6e94',1,'apr_getopt_option_t']]],
  ['os_5fsock_2',['os_sock',['../structapr__os__sock__info__t.html#a952464d2f91ca4650e8b4848a81745b5',1,'apr_os_sock_info_t']]],
  ['out_3',['out',['../structapr__proc__t.html#acb7d7c5226217946d761f0e90ff70d24',1,'apr_proc_t']]]
];
