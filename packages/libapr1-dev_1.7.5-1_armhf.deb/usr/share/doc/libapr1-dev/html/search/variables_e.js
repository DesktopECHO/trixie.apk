var searchData=
[
  ['ref_0',['ref',['../structapr__memnode__t.html#ac68a939c0c3d48498ec0c0fde409c502',1,'apr_memnode_t']]],
  ['remote_1',['remote',['../structapr__os__sock__info__t.html#ae71fe14a5eb9141fc4ad0a6d0a91f17e',1,'apr_os_sock_info_t']]],
  ['reqevents_2',['reqevents',['../structapr__pollfd__t.html#abcedac7097a97823a38ece6e47f4ea9f',1,'apr_pollfd_t']]],
  ['reset_3',['reset',['../structapr__getopt__t.html#abc4e72bc761666c0b0d9015c3b0de8c3',1,'apr_getopt_t']]],
  ['rtnevents_4',['rtnevents',['../structapr__pollfd__t.html#aed5b2109b27984975309922bfa84e3f6',1,'apr_pollfd_t']]]
];
